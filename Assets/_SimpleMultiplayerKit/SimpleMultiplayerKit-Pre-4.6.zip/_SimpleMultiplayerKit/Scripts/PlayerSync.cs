﻿using UnityEngine;
using System.Collections;
     
    /// <summary>
    /// This script is attached to the player and it
    /// ensures that every players position, rotation, and scale,
    /// are kept up to date across the network.
    ///
    /// This script is closely based on a script written by M2H,
    /// and edited by AnthonyB28 ( https://github.com/AnthonyB28/FPS_Unity/blob/master/MovementUpdate.cs )
    /// </summary>
     
     
public class PlayerSync : MonoBehaviour {
       
    private Vector3 lastPosition;
    private Quaternion lastRotation;
    private Transform myTransform;
	
    void Start ()
    {
        if(networkView.isMine == true)
        {
            myTransform = transform;
			if(!Network.isServer)
				networkView.RPC("UpdateMovement", RPCMode.OthersBuffered, myTransform.position, myTransform.rotation);	//Make sure everyone sees the player at right location the moment he spawns 
        }
        else
        {
            enabled = false;
        }
    }
	
	[RPC]
	void SetUsername (string name){
		gameObject.name = name;
	}
	
	
    void Update ()
	{
		if(Vector3.Distance(myTransform.position, lastPosition) >= 0.1f){
			//If player has moved, send move update to other players
        	//Capture the player's position before the RPC is fired off and use this
			//to determine if the player has moved in the if statement above.
        	lastPosition = myTransform.position;
        	networkView.RPC("UpdateMovement", RPCMode.OthersBuffered, myTransform.position, myTransform.rotation);
		}
        if(Quaternion.Angle(myTransform.rotation, lastRotation) >= 5f){
        	//Capture the player's rotation before the RPC is fired off and use this
        	//to determine if the player has turned in the if statement above. 
        	lastRotation = myTransform.rotation;   
        	networkView.RPC("UpdateMovement", RPCMode.OthersBuffered, myTransform.position, myTransform.rotation);
		}
	}
    [RPC]
    void UpdateMovement (Vector3 newPosition, Quaternion newRotation)
    {
		transform.position = newPosition;
        transform.rotation = newRotation;
    }
}