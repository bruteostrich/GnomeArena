﻿using UnityEngine;
using System.Collections;
using System.Text.RegularExpressions;			// This allows us to use Regex for turning the fields into numbers-only fields, or text-only fields

public class NetworkManager : MonoBehaviour {

	public string gameName = "SUNKExample";		// When RefreshHostList() is called, only servers with this exact string will be displayed CTRL-F GNINFO FOR IMPORTANT INFO
	private string serverName = "Example name";	// This is the name that will be displayed when returned by RefreshHostList()
	public string serverPort = "25000";			// This is the port you'd like to use; useful to know/change if you need to port forward
	public string username = "";				// What you want your username to be
	public string password = "";				// The password for the server; needed to join a passworded server, or to create a private server
	public string maxPlayers = "4";				// Maximum number of players allowed in the server; CTRL-F MPINFO FOR IMPORTANT INFO
	public bool privateServer = false;			// If this is true, then the server will become password-protected, and only those with the password can join
	public bool dedicated = false;				// If true, the server host won't spawn as a player, but will still be joinable. A separate instance is required for the server host to join and play
	public bool showAdminMenu = false;			// If dedicated is true, this will be shown on screen; customize it to display appropriate admin functions

	private HostData[] hostList;				// This is where the list of servers will be stored later

	public Transform[] spawnZones;				// This is where we store the Transform data of the spawn points, used when spawning the players
	public GameObject playerObject;				// This is where we store the GameObject data of the player character; This can be transformed into an array, if you'd like to create a character-select
	
	public GUIText debug;						// This is where we drag the debug GUIText to in the editor

	Vector2 scrollPosition;
	
	//===========
	// This is where we check NAT settings
	// Check http://docs.unity3d.com/Documentation/ScriptReference/Network.TestConnection.html for more information
	string testStatus = "Testing network connection capabilities.";
	string testMessage = "Test in progress.";
	string shouldEnableNatMessage = "";
	public bool doneTesting = false;
	bool probingPublicIP = false;
	ConnectionTesterStatus connectionTestResult = ConnectionTesterStatus.Undetermined;
	bool useNat = false;
	//===========
	
	void Awake () {
		// On Awake, we want to ensure the master server is empty, and a placeholder username is chosen
		MasterServer.ClearHostList();
		username = "Player"+Random.Range(0,99).ToString();	// We're randomizing a digit at the end, just to give some variety
	}
	
	private void StartServer() {
		// This is where we start creating the server
		
		// All these 'else if' statements are just to warn the player that a field is incorrectly filled
		// Once all fields are appropriately filled, then the server will be created
		if(serverPort == "" || int.Parse(serverPort)<=0 || int.Parse(serverPort)>65535){
			debug.text = "Invalid Port Number\n"+debug.text;
		}
		else if(maxPlayers == "" || int.Parse(maxPlayers) <= 0){
			debug.text = "Invalid Max Players Number\n"+debug.text;
		}
		else if(serverName == ""){
			debug.text = "Invalid Server Name\n"+debug.text;
		}
		else if(username == ""){
			debug.text = "Invalid Userame\n"+debug.text;
		}
		else if(serverPort == ""){
			debug.text = "Invalid Port Number\n"+debug.text;
		}
		else if(privateServer && password == ""){
			debug.text = "Invalid Password\n"+debug.text;
		}
		else{
			if(password != "" && privateServer){
				Network.incomingPassword = password;
				Network.InitializeServer(int.Parse(maxPlayers)-1, int.Parse(serverPort), useNat); 	// we check whether useNat is needed later on automatically. Again, the documentation mentioned earlier will provide better explanation
				MasterServer.RegisterHost(gameName, "[P]"+serverName);								// Now we register the server, using the unique gameName assigned earlier, and the server name assigned by the player.
																									// This will display "[P]" in front of the server if there is a password
			}
			else if(password == "" || !privateServer){												// If we haven't put in a password, or if privateServer is false, go ahead and create a public server
				Network.InitializeServer(int.Parse(maxPlayers)-1, int.Parse(serverPort), useNat);
				MasterServer.RegisterHost(gameName, serverName);
			}
		}
	}
	
	void OnServerInitialized() {
		// Once the server is created, check if we are dedicated or not;
		// If we're dedicated, don't spawn a player, instead show the admin menu. Otherwise, spawn the player
		
		Debug.Log("Server Initialized");
		if(dedicated){
			showAdminMenu = true;
		}else{
			SpawnPlayer();
		}
	}
	
	private void JoinServer (HostData hostdata) {
		// When invoked, check if the server has a password. If it does, check it against the password entered in the password field. If not, ignore the password field
		if(hostdata.passwordProtected){
			Network.Connect(hostdata,password);
		}else{
			Network.Connect(hostdata);
		}
	}
	
	private void OnConnectedToServer() {
		Debug.Log("Server Joined");
		// If we successfully join the server, spawn our player object
		SpawnPlayer();
	}
	
	private void SpawnPlayer()	{
		// Spawning the player. By using Network.Instantiate instead of just Instantiate, everyone on the server will have the player object instantiated (Though control should be reserved only to the owner of the NetworkView)
		int randomSpawn = Random.Range(0, spawnZones.Length-1);	// We're choosing random spawn points from an array just for convenience here - you can handle this how you like, just keep in mind: Network.Instantiate creates the object on everyone's end
		GameObject networkPlayer = Network.Instantiate(playerObject, spawnZones[randomSpawn].transform.position, Quaternion.identity, 0) as GameObject;
		networkPlayer.networkView.RPC("SetUsername", RPCMode.AllBuffered, username);
	}
	
	private void RefreshHostList() {
		// When invoked, clear out the host list of previous data, and get a fresh list
		MasterServer.ClearHostList();
		MasterServer.RequestHostList(gameName);
	}
	
	void OnMasterServerEvent(MasterServerEvent msEvent) {
		if(msEvent == MasterServerEvent.HostListReceived){
			hostList = MasterServer.PollHostList();
		}
	}

	void OnFailedToConnect (NetworkConnectionError error){
		// If we can't connect, tell the user why
		debug.text = "Error: "+error.ToString()+"\n" +debug.text;
	}


	void OnPlayerDisconnected(NetworkPlayer player){
		// When a player disconnects, we clean up after the player by doing the following
		Debug.Log("Cleaning up after player " + player);
		Network.RemoveRPCs(player);
		Network.DestroyPlayerObjects(player);
	}

	void OnDisconnectedFromServer (NetworkDisconnection info){
		// In here, we can check why we've been disconnected, and do things accordingly.
		// In this case, we check why we DC'd, then reload the level to get back to the menu
		if(info == NetworkDisconnection.Disconnected){debug.text = "Disconnected\n"+debug.text;}
		else if(info == NetworkDisconnection.LostConnection){debug.text = "LostConnection\n"+debug.text;}
		Application.LoadLevel(1);
	}
		
	void OnGUI () {
		if(showAdminMenu){
			if(GUI.Button(new Rect(100,125,125,25), "Close Server")){
				if(Network.isServer){
					for(int i = 0; i< Network.connections.Length;i++){
						Network.CloseConnection(Network.connections[i],true);
					}
				}
				Network.Disconnect();
				Application.LoadLevel(1);
			}
		}
		// If we're not joined to or hosting a server, then we can only be in the menu, so we unlock the cursor and show it
		if(!Network.isClient && !Network.isServer){
			Screen.lockCursor = false;
			Screen.showCursor = true;
			showAdminMenu = false;
			
			// This uses the built-in GUI functions of Unity, which aren't the most beginner-friendly
			// Basic descriptions are given, but for more in-depth information, I suggest researching more about Unity's GUI, or even investing in a 3rd-party solution
			
			GUI.Box (new Rect(387.5f,95,550,170),"");							// We make a box to act as a sort of background, so that we can read the text and fields better
			
			GUI.Label(new Rect(400,100,250,25),"Server Name");
			serverName = GUI.TextField(new Rect(400,125,250,25),serverName,16);	// This changes the string 'serverName' to be whatever is in the text field
			
			GUI.Label(new Rect(675,100,250,25),"Port");
			serverPort = GUI.TextField(new Rect(675,125,250,25),serverPort,5);	// This is a numbers-only field, only allowing up to 5 digits
			serverPort = Regex.Replace(serverPort, @"[^0-9]","");
			
			GUI.Label(new Rect(675,150,250,25),"Max Players");
			maxPlayers = GUI.TextField(new Rect(675,175,250,25),maxPlayers,2);	// This is also a numbers-only field, but only allowing 2 digits
			maxPlayers = Regex.Replace(maxPlayers, @"[^0-9]","");

			GUI.Label(new Rect(400,150,250,25),"Username");
			username = GUI.TextField(new Rect(400,175,250,25),username,16);		// This allows up to 16 characters be used for the username
			
			GUI.Label(new Rect(400,200,250,25),"Server Password");
			password = GUI.PasswordField(new Rect(400,225,250,25),password,"*"[0],8);	// This is a password field, but shows the entered characters as stars for security

			dedicated = GUI.Toggle(new Rect(675,225,75,25),dedicated, "Dedicated");		// This is a toggle button to change the value of the 'dedicated' bool

			privateServer = GUI.Toggle(new Rect(800,225,75,25),privateServer, "Password");	// This toggles between whether 'privateServer' is true or not

			if(GUI.Button(new Rect(100,100,250,75), "Start Server")){					// This button invokes StartServer()
				StartServer();
			}
			if(GUI.Button(new Rect(100,260,250,75), "Refresh Hosts")){					// This one invokes RefreshHostList
				RefreshHostList();
			}
			GUI.Box (new Rect(387.5f,270,306.25f,350),"");				//These two just act as a background for the server list, and a title to let the players know this is where the server list is
			GUI.Label(new Rect(400,275,275,25),"Server list:");

			if(hostList != null){										// If there is data in the hostList, display each server as a button
				GUILayout.BeginArea(new Rect(387.5f,300,312.5f,312.5f),"");	// Here is where we put the displayed buttons in a scroll list - Unity GUI is especially difficult to work with for this purpose, so I recommend either researching more into this to understand, or going to a third-party source
				scrollPosition = GUILayout.BeginScrollView(scrollPosition, GUILayout.Width(300), GUILayout.Height(312.5f));
				for(int i = 0; i < hostList.Length; i++){
					if(GUILayout.Button(hostList[i].gameName + " | " + hostList[i].connectedPlayers + "/" + hostList[i].playerLimit + " players")){
						if(username != "")
							JoinServer(hostList[i]);
					}
				}
				GUILayout.EndScrollView();
				GUILayout.EndArea();
			}
			
			//====CHECK NAT====//
			GUILayout.BeginArea(new Rect(725,287.5f,200,200),"");
			GUILayout.Label("Current Status: " + testStatus);
			GUILayout.Label("Test result : " + testMessage);
			GUILayout.Label(shouldEnableNatMessage);
			
			if (!doneTesting){
				//If not testing, then run the test
				TestConnection();
			}
			GUILayout.EndArea();
		}else{
			if(!showAdminMenu){
			Screen.lockCursor = true;
			Screen.showCursor = false;
			}
			//If we're in a game, clear out the dubug text to avoid obscuring the view of the player
			debug.text = "";
			//If we hit the 'P' key, return to the menu
			if(Input.GetKeyDown(KeyCode.P)){
				Network.Disconnect();
				Application.LoadLevel(1);
			}
		}
	}

	void TestConnection () {
		float timer = Time.time;
		// Start/Poll the connection test, report the results in a label and 
		// react to the results accordingly
		connectionTestResult = Network.TestConnection();
		switch (connectionTestResult) {
		case ConnectionTesterStatus.Error: 
			testMessage = "Problem determining NAT capabilities";
			doneTesting = true;
			break;
			
		case ConnectionTesterStatus.Undetermined: 
			testMessage = "Undetermined NAT capabilities";
			doneTesting = false;
			break;
			
		case ConnectionTesterStatus.PublicIPIsConnectable:
			testMessage = "Directly connectable public IP address.";
			useNat = false;
			doneTesting = true;
			break;
			
			// This case is a bit special as we now need to check if we can 
			// circumvent the blocking by using NAT punchthrough
		case ConnectionTesterStatus.PublicIPPortBlocked:
			testMessage = "Non-connectable public IP address (port " + serverPort +" blocked), running a server is impossible.";
			useNat = false;
			// If no NAT punchthrough test has been performed on this public 
			// IP, force a test
			if (!probingPublicIP) {
				connectionTestResult = Network.TestConnectionNAT();
				probingPublicIP = true;
				testStatus = "Testing if blocked public IP can be circumvented";
				timer = Time.time + 10;
			}
			// NAT punchthrough test was performed but we still get blocked
			else if (Time.time > timer) {
				probingPublicIP = false; 		// reset
				useNat = true;
				doneTesting = true;
			}
			break;
		case ConnectionTesterStatus.PublicIPNoServerStarted:
			testMessage = "Public IP address but server not initialized, "+
				"it must be started to check server accessibility. Restart "+
					"connection test when ready.";
			break;
			
		case ConnectionTesterStatus.LimitedNATPunchthroughPortRestricted:
			testMessage = "Limited NAT punchthrough capabilities. Cannot "+
				"connect to all types of NAT servers. Running a server "+
					"is ill advised as not everyone can connect.";
			useNat = true;
			doneTesting = true;
			break;
			
		case ConnectionTesterStatus.LimitedNATPunchthroughSymmetric:
			testMessage = "Limited NAT punchthrough capabilities. Cannot "+
				"connect to all types of NAT servers. Running a server "+
					"is ill advised as not everyone can connect.";
			useNat = true;
			doneTesting = true;
			break;
			
		case ConnectionTesterStatus.NATpunchthroughAddressRestrictedCone:
		case ConnectionTesterStatus.NATpunchthroughFullCone:
			testMessage = "NAT punchthrough capable. Can connect to all "+
				"servers and receive connections from all clients. Enabling "+
					"NAT punchthrough functionality.";
			useNat = true;
			doneTesting = true;
			break;
			
		default: 
			testMessage = "Error in test routine, got " + connectionTestResult;
			break;
		}
		if (doneTesting) {
			if (useNat)
				shouldEnableNatMessage = "When starting a server the NAT "+
					"punchthrough feature should be enabled (useNat parameter)";
			else
				shouldEnableNatMessage = "NAT punchthrough not needed";
			testStatus = "Done testing";
		}
	}
}

//	===== GNINFO =====	//
//
//	It is important to note, that any other Unity Game that uses the same Game Name as this
//	will also be displayed, though connection may not be possible. I recommend changing this
//	as soon as possible, to something with more obscurity. EG/ if your game were named Dario,
//	something like Dario2014Alpha01131a would be obscure enough that the chances of someone else
//	using it would be astronomically low. I personally use the convention GameNameDateVersion due to the high obscurity
//	
//	==================	//


//	===== MPINFO =====	//
//
//	While maxPlayers is set to X, it actually has 1 subtracted from
//	that value when used; this is because it actually treats the number
//	as an array index (where Object 1 is indexed at 0)
//	
//	Because most players would reasonably assume that making a server only
//	1 slot would mean only 1 player is allowed (instead of 1 slot for 2 players),
//	this caters to a perfectly reasonable assumption.
//
//	It's important to know this when either customizing this script, or creating one from scratch,
//	to prevent unwanted server issues
//
//	==================	//