﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour {
	
	// How you use the game manager is up to you - just keep in mind that this will be on each client,
	// so try to avoid putting any conflicting code in here
	
	// The included script ensures there will only be one GameManager in your scene at any given time
	
	private static GameManager instance = null;
	public static GameManager Instance{
		get{
			if (instance == null){
				instance = (GameManager)FindObjectOfType(typeof(GameManager));
			}
			return instance;
		}
	}
	
	void Awake() {
		if (!networkView.isMine){
			enabled = false;
		}
		if (Instance != this){
			Destroy(gameObject);
			Debug.Log ("DestroyedObjectPersist");
		}
		else{
			DontDestroyOnLoad(gameObject);
		}
	}
}
