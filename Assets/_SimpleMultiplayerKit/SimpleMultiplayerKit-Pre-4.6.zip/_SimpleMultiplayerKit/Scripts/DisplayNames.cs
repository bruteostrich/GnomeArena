﻿using UnityEngine;
using System.Collections;

public class DisplayNames : MonoBehaviour {
	
	[SerializeField] GameObject nameDisplayObject;	//This is the 3DText, or GameObject with TextMesh component
	
	// Use this for initialization
	void Start () {
		nameDisplayObject.GetComponent<TextMesh>().text = gameObject.name;	//Since the player's object is named the same as their Username,
																			//we can just reference the gameObject's name.
	}
}
