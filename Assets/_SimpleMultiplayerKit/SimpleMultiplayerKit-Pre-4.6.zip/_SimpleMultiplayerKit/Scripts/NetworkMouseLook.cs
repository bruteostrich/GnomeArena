using UnityEngine;
using System.Collections;

// This script is practically the same as the default MouseLook.cs, except with network checks to automatically disable if required

[AddComponentMenu("Camera-Control/Mouse Look")]
public class NetworkMouseLook : MonoBehaviour {

	public enum RotationAxes { MouseXAndY = 0, MouseX = 1, MouseY = 2 }
	public RotationAxes axes = RotationAxes.MouseXAndY;
	public float sensitivityX = 15F;
	public float sensitivityY = 15F;

	public float minimumX = -360F;
	public float maximumX = 360F;

	public float minimumY = -60F;
	public float maximumY = 60F;

	float rotationY = 0F;
	
	void Start () {
		
		// Because this script is attached to both the player and the camera, we need to make sure additional cameras aren't enabled on our side
		// We do this by first checking if it's attached to a camera
		if(camera){
			// After, if this is a camera, we check if the parent object is ours or not. If not, we'll disable it
			if(!transform.parent.networkView.isMine){
			//If this object doesn't belong to us, disable it on our end
				gameObject.SetActive(false);
			}
		}else{
			if(!networkView.isMine){
				enabled = false;
			}
		}
		// Make the rigid body not change rotation
		if (rigidbody)
			rigidbody.freezeRotation = true;
	}
	
	void Update ()
	{
		if (axes == RotationAxes.MouseXAndY)
		{
			float rotationX = transform.localEulerAngles.y + Input.GetAxis("Mouse X") * sensitivityX;
			
			rotationY += Input.GetAxis("Mouse Y") * sensitivityY;
			rotationY = Mathf.Clamp (rotationY, minimumY, maximumY);
			
			transform.localEulerAngles = new Vector3(-rotationY, rotationX, 0);
		}
		else if (axes == RotationAxes.MouseX)
		{
			transform.Rotate(0, Input.GetAxis("Mouse X") * sensitivityX, 0);
		}
		else
		{
			rotationY += Input.GetAxis("Mouse Y") * sensitivityY;
			rotationY = Mathf.Clamp (rotationY, minimumY, maximumY);
			
			transform.localEulerAngles = new Vector3(-rotationY, transform.localEulerAngles.y, 0);
		}
	}
}